using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class regularEnemy : MonoBehaviour
{
    public float moveSpeed = 2f;
    public int detectionDistance = 7;
    public int stanceDistance = 2;

    Rigidbody2D enemyRB;
    Rigidbody2D playerRB;

    Vector2 movement;
    Vector2 epsilon = new Vector2(0.01f, 0.01f);

    void Start()
    {
        //gets the enemie's rigidbody
        enemyRB = GetComponent<Rigidbody2D>();

        //gets the player's rigidbody
        GameObject player = GameObject.Find("Player");
        playerRB = player.GetComponent<Rigidbody2D>();
    }

    void FixedUpdate()
    {
        float angle = Mathf.Atan2(playerRB.position.y - enemyRB.position.y, playerRB.position.x - enemyRB.position.x);

        movement.x = Mathf.Cos(angle);
        movement.y = Mathf.Sin(angle);

        float distance = Mathf.Sqrt(Mathf.Pow(playerRB.position.x - enemyRB.position.x, 2) + Mathf.Pow(playerRB.position.y - enemyRB.position.y, 2));

        //only moves if player is within range
        if (distance < detectionDistance)
        {
            //move towards
            if (distance > stanceDistance)
                enemyRB.MovePosition(enemyRB.position + movement * moveSpeed * Time.fixedDeltaTime);
            //move away
            if (distance < stanceDistance)
                enemyRB.MovePosition(enemyRB.position + movement * moveSpeed * -1 * Time.fixedDeltaTime);
        }
    }
}
