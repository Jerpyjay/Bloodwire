using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum PlayerState
{
    Walking,
    Attacking
}

public class playerMovement : MonoBehaviour
{
    public float moveSpeed = 5f;
    public PlayerState currentState;
    public Rigidbody2D rb;
    public Animator animator;

    Vector2 movement;

    void Start()
    {
        currentState = PlayerState.Walking;
    }
    
    // Update is called once per frame
    void Update()
    {

        //input
        movement.x = Input.GetAxisRaw("Horizontal");
        movement.y = Input.GetAxisRaw("Vertical");
        updateAnimationAndMove();

        if(Input.GetButtonDown("Fire1") && currentState != PlayerState.Attacking)
        {
            animator.SetBool("Attacking", true);
        }
        else
        {
            updateAnimationAndMove();
        }
        
    }

    void updateAnimationAndMove()
    {
        animator.SetFloat("Horizontal", movement.x);
        animator.SetFloat("Vertical", movement.y);
        animator.SetFloat("Speed", movement.sqrMagnitude);
        animator.SetBool("Attacking", false);
        moveCharacter();
    }

    void moveCharacter()
    {
        rb.MovePosition(rb.position + movement * moveSpeed * Time.fixedDeltaTime);
    }

}
